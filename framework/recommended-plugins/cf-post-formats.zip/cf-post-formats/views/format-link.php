<div class="cf-elm-block" id="cfpf-format-link-url" style="display: none;">
	<label for="cfpf-format-link-url-field"><?php _e('URL', 'cf-post-format'); ?></label>
	<input type="text" name="_format_link_url" value="<?php echo esc_attr(get_post_meta($post->ID, '_format_link_url', true)); ?>" id="cfpf-format-link-url-field" tabindex="1" />
</div>	